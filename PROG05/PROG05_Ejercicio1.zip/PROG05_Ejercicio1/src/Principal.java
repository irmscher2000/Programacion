// Eugen Moga
// PROG05 Tarea

import java.time.LocalDate;                     // Para poder utilizar LocalDate



/**
 * Clase Principal que contiene el metodo main y la utilizo para realizar las pruebas de la clase Persona
 * @author Eugen Moga
 * @version 1.0
 */
class Principal {
    
    public static void main(String[] args) {
        
        // Creo dos objetos de la clase persona
        Persona p1 = new Persona("12345678A", "Eugen", "Moga", 'M',LocalDate.of(1990, 12, 02), true, "Rumania", "Tudela");
        Persona p2 = new Persona("12345678B", "Eugenia", "Mola", 'F',LocalDate.of(1990, 12, 25), false, "España", "Pamplona");
        Persona p3 = new Persona();
        
        // Mostrar numero de instancias 
        System.out.println("Número de personas creadas: " + Persona.getNumeroInstancias());
        System.out.println(" ");
        
        // Muestra información en formato normal
        System.out.println("Información de persona 1 normal: ");
        p1.getInfo(FormatoSalida.NORMAL);
        System.out.println(" ");
        
        // Muestra información en formato pausado
        System.out.println("Información de persona 2 (pausado) pulse intro para continuar: ");
        p2.getInfo(FormatoSalida.PAUSADO);
        System.out.println(" ");
        
        // Comparar edad con otra persona
        System.out.println("\nComparación de edad entre dos personas");
        System.out.println("Compara la edad de " + p1.getNombre() + " con " + p2.getNombre());
        p1.compararEdad(p2);
        
        // Compara la edad con una fecha especifica
        LocalDate fechaComparacion = LocalDate.of(2010, 1, 1);
        System.out.println("\nComparación de edad con una fecha especifica");
        System.out.println("Compara la edad con la fecha " + fechaComparacion);
        p1.compararEdad(fechaComparacion);
        
        // Comparar edad con un numero
        int numeroComparacion = 37;
        System.out.println("\nCompara la edad con el número: " + numeroComparacion);
        p1.compararEdad(numeroComparacion);
        
        // Comparar edad con una fecha en formato (ddMMyyyy)
        System.out.println("\nComparación de edad con fecha en formato (ddMMyyyy)23061998");
        p1.compararEdad("23061998");
        
    }
    
}

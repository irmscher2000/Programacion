// Eugen Moga
// PROG05 Tarea
// He enumerado cada Apartado de la tarea para facilitar la implementacion y no dejarme nada.
/**
* @author Eugen Moga
* @version 1.0
*/

import java.time.LocalDate;                     // Para poder utilizar LocalDate
import java.time.format.DateTimeFormatter;      // Para formatear y parsear fechas
import java.util.Scanner;                       // Para la entrada de datos por el usuario
import java.time.Period;                        // Para calcular la diferencia entre dos fechas


public class Persona {
    
    // Apartado 2.3
    /**
     * Metodo estatico para incrementar y obtener instancias
     *  
     */
    private static int numeroInstancias = 0;
    private static void incrementarNumeroInstancias(){
        numeroInstancias++;
    }
    public static int getNumeroInstancias(){
        return numeroInstancias;
    }
    
    // Apartado 1.1 Creacion de los atributos de la clase
    /**
     * 
     * Representa una persona con los atributos DNI, nombre, apellidos, sexo, 
     * fecha de nacimiento, carnet de conducir, nacionalidad y dirección.
     * Incluyendo métodos para comparar edades y obtener información formateada
     * 

     */
    // Atributos privados, solo pueden verse por la propia clase persona
    private String dni;
    private String nombre;
    private String apellidos;
    private char sexo;  // "M" para masculino, "F" para femenino
    private LocalDate fechaNacimiento; 
    private boolean tieneCarnet;
    private String nacionalidad;
    private String direccion; 
    
    // Apartado 2.1 
    /**
     * Constructor con parámetros.
     * @param dni DNI de la persona.
     * @param nombre Nombre de la persona.
     * @param apellidos Apellidos de la persona.
     * @param sexo Sexo de la persona ('M' o 'F').
     * @param fechaNacimiento Fecha de nacimiento en formato YYYY-MM-DD.
     * @param tieneCarnet Indica si tiene carnet de conducir.
     * @param nacionalidad Nacionalidad de la persona.
     * @param direccion Dirección de la persona.
     */
    public Persona(String dni, String nombre, String apellidos, char sexo, LocalDate fechaNacimiento, 
            boolean tieneCarnet, String nacionalidad, String direccion) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.tieneCarnet = tieneCarnet;
        this.nacionalidad = nacionalidad;
        this.direccion = direccion;
        incrementarNumeroInstancias();
    }

    // Apartado 2.2
    /**
     * Constructor por defecto
     * Inicializa los valores a un valor por defecto
     */
    public Persona(){
        this.dni = "";
        this.nombre = "";
        this.apellidos = "";
        this.sexo = 'M';
        this.fechaNacimiento = LocalDate.of(1900, 1, 1);
        this.tieneCarnet = false;
        this.nacionalidad = "";
        this.direccion = "";
        incrementarNumeroInstancias();
    }
    
    // Apartado 1.2 Metodo getters y setters introducidos automaticamente clic derecho insert code
    /**
     * Obtiene el DNI de la persona
     * @return DNI de la persona
     */
    public String getDni() {
        return dni;
    }

    /**
     * Establece el DNI de la persona
     * @param dni DNI de la persona
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Obtiene el nombre de la persona
     * @return nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Estable el nombre de la persona
     * @param nombre Nombre de la persona
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Estable los apellidos de la persona
     * @return apellidos de la persona
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Establece los apellidos de la persona
     * @param apellidos Apellidos de la persona
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * Obtiene el sexo de la persona
     * @return Sexo de la persona "M" o "F"
     */
    public char getSexo() {
        return sexo;
    }

    /**
     * Establece el sexo de la persona
     * @param sexo Sexo de la persona "M" o "F"
     */
    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    /**
     * Obtiene la fecha de nacimiento de la persona
     * @return Fecha de nacimiento de la persona
     */
    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Establece la fecha de nacimiento de la persona
     * @param fechaNacimiento Fecha de nacimiento de la persona
     */
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Indica si la persona tiene carnet de conducir
     * @return true si tiene carnet de conducir, false si no tiene
     */
    public boolean isTieneCarnet() {
        return tieneCarnet;
    }

    /**
     * Establece si la persona tiene carnet de conducir
     * @param tieneCarnet true si tiene carnet de conducir, false en caso contrario
     */
    public void setTieneCarnet(boolean tieneCarnet) {
        this.tieneCarnet = tieneCarnet;
    }

    /**
     * Obtiene la nacionalidad de la persona
     * @return Nacionalidad de la persona
     */
    public String getNacionalidad() {
        return nacionalidad;
    }

    /**
     * Establece la nacionalidad de la persona
     * @param nacionalidad Nacionalidad de la persona
     */
    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    /**
     * Obtiene la dirección de la persona
     * @return Direccion de la persona
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección de la persona
     * @param direccion Dirección de la persona
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
        
    // Apartado 3.1 Método getInfo
    /**
     * Obtine la informacion de la persona en el formato especificado.
     * @param formato Formato de la informacion: PAUSADO o NORMAL
     */
    public void getInfo(FormatoSalida formato){
        switch (formato){
            case PAUSADO -> {
                // Muestra formato "pausado"
                Scanner sc = new Scanner(System.in);
                System.out.println("DNI: " + dni);
                sc.nextLine();
                System.out.println("Nombre: " + nombre);
                sc.nextLine();
                System.out.println("Apellidos: " + apellidos);
                sc.nextLine();
                System.out.println("Sexo: " + sexo);
                sc.nextLine();
                System.out.println("Fecha de nacimiento: " + fechaNacimiento);
                sc.nextLine();
                System.out.println("Tiene carnet de conducir: " + tieneCarnet);
                sc.nextLine();
                System.out.println("Nacionalidad: " + nacionalidad);
                sc.nextLine();
                System.out.println("Dirección: " + direccion);
            }
            case NORMAL -> {
                //Muestra formato "normal"
                System.out.println("Información de la persona");
                System.out.println("DNI: " + dni);
                System.out.println("Nombre: " + nombre);
                System.out.println("Apellidos: " + apellidos);
                System.out.println("Sexo: " + sexo);
                System.out.println("Fecha de nacimiento: " + fechaNacimiento);
                System.out.println("Tiene carnet de conducir: " + tieneCarnet);
                System.out.println("Nacionalidad: " + nacionalidad);
                System.out.println("Dirección: " + direccion);
            }
            default -> throw new AssertionError(formato.name());
        }
    }
    
    // Apartado 3.2 Método calcularEdad
    /**
     * Método calcularEdad
     * @return Period Calcula la diferencia en años entre la fecha de nacimiento y la fecha actual
     */
    public int calcularEdad(){
        return Period.between(fechaNacimiento, LocalDate.now()).getYears();
    }
    
    /**
     * Compara la edad con otra persona
     * @param p1 Compara la fecha entre 2 personas
     */
    public void compararEdad(Persona p1){                                                        
        LocalDate fechaActual = LocalDate.now();
        // Calcula la edad de la persona pasada como parámetro (p1) restando su fecha de nacimiento de la fecha actual.
        int edadOtra = Period.between(p1.getFechaNacimiento(), fechaActual).getYears();
        compararEdad((int) edadOtra);
    }
    
    // Apartado 3.2 Métodos sobrecargados para comparar edad con una fecha
    /**
     * Compara la edad con una fecha
     * @param fecha Fecha con la que se compara la edad
     */
    public void compararEdad(LocalDate fecha){
        // Calcula la diferencia en años entre la fecha proporcionada (fecha) y la fecha actual, 
        int edadComparativa = Period.between(fecha, LocalDate.now()).getYears();
        compararEdad((int) edadComparativa);
    }
          
    // Apartado 3.2 Métodos sobrecargados para comparar edad con un numero
    /**
     * Comparar la edad con un numero
     * @param anio Años con los que se compara
     */
    public void compararEdad(int anio){
        int edadPropia = calcularEdad();
        if (edadPropia > anio){
            System.out.println(this.nombre + " es mayor");
        } else if (edadPropia < anio){
            System.out.println(this.nombre + " es menor");
        } else {
            System.out.println("Tienen la misma edad");
        }
    }
    
    // Apartado 3.3 Método sobrecargado comparar edad con String
    /**
     * Comparar edad con String "23061998"
     * @param fecha Compara la edad con una cadena String 
     */
    public void compararEdad(String fecha){
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("ddMMyyyy");
        LocalDate fechaParseada = LocalDate.parse(fecha, formato);
        compararEdad(fechaParseada);
    }
    
}

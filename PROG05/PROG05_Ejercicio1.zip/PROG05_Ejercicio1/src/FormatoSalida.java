
/**
 * @author Eugen Moga
 * @version 1.0
 */

/**
 * Enum separado de la clase persona 
 */
public enum FormatoSalida {
PAUSADO,
NORMAL
}


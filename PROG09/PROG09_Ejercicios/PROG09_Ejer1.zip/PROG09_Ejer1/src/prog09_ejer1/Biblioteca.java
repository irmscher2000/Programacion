
// Eugen Moga
// PROG09 Ejercicio 1

package prog09_ejer1;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


public class Biblioteca {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        // Cargo los libros antes de entrar al menú para evitar sobrescribir los datos que hay en Libros.dat
        List<Libro> libros = cargarLibros();        
        
        int opcion ;
        
        do{
            // Menú de la biblioteca
            System.out.println("\n-------------------------");
            System.out.println("---- Menú Biblioteca ----");
            System.out.println("1. Añadir Libro");
            System.out.println("2. Guardar Libros");
            System.out.println("3. Cargar Libros");
            System.out.println("4. Mostrar Libros");
            System.out.println("5. Eliminar Libro");
            System.out.println("6. Salir");
            System.out.println("-------------------------\n");
            
            // Bucle para validar que se ingresa un número del menú
            while(true){
                System.out.println("Seleccione una opcion: ");
                try{
                    opcion = sc.nextInt();
                    sc.nextLine();          // Consume el salto de línea
                    break;
                } catch (InputMismatchException e){
                    System.out.println("Error: Debe ingresar un número valido");
                    sc.nextLine();          // Limpia el buffer
                }
            }
            
            // Switch para manejar las opciones del menú
            switch(opcion){
                case 1: 
                    libros.add(agregarLibro(sc));
                    System.out.println("Libro añadido correctamente.");
                    break;
                    
                case 2:
                    guardarLibros(libros);
                    break;
                    
                case 3:
                    libros = cargarLibros();
                    break;
                    
                case 4:
                    mostrarLibros(libros);
                    break;
                    
                case 5:
                    eliminarLibro(sc, libros);
                    break;
                    
                case 6:
                    System.out.println("Saliendo del programa.");
                    return;
                    
                default:
                    System.out.println("Opción no válida. intente de nuevo.");
            }
        }while (opcion != 6);
        sc.close();
    }
    
    
    // Método guardar la lista de libros en un archivo.
    public static void guardarLibros(List<Libro>libros){
        try{
            FileOutputStream fichero = new FileOutputStream("Libros.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fichero);
            oos.writeObject(libros);
            oos.close();
            System.out.println("Libros guaradados con exito. ");
            
        }catch (IOException e){
            System.out.println("Error al guardar libro: " + e.getMessage());
        }
    }
    
    
    // Metodo cargar la lista de los libros de un archivo.
    public static List<Libro>cargarLibros(){
        List<Libro>libros = new ArrayList<>();
        
        try {
            FileInputStream fichero = new FileInputStream("Libros.dat");
            ObjectInputStream ois = new ObjectInputStream(fichero);
            
            libros = (List<Libro>) ois.readObject();
            ois.close();
            System.out.println("Libros cargados correctamente.");
            
        }catch (FileNotFoundException e){
            System.out.println("No se encontró el archivo. Aún no hay libros guardados.");
        
        }catch (IOException e){
            System.out.println("Error al leer el archivo: " + e.getMessage());
            
        }catch (ClassNotFoundException e){
            System.out.println("Error: Clase Libro no encontrada" + e.getMessage());
        }
        return libros;
    }
    
    
    // Metodo para mostrar todos los libros
    public static void mostrarLibros(List<Libro> libros){
        if(libros.isEmpty()){
            System.out.println("No hay libros en la biblioteca");
        }else {
            int i = 1;
            for (Libro l : libros){
                System.out.println("Libro nº " + i +": " + l);
                i++;
            }
        }
    }
    
    
    // Metodo para eliminar Libro
    public static void eliminarLibro(Scanner sc, List<Libro> libros){
        if (libros.isEmpty()){
            System.out.println("No hay libros en la biblioteca para eliminar.");
            return;
        }
        mostrarLibros(libros);
        
        int i;
        while(true){
            System.out.println("Ingresa el número del indice del libro que deseas eliminar: ");
            
            try{
                i = sc.nextInt();
                sc.nextLine(); // Consume el salto de linea
                
                if (i < 1 || i > libros.size()){
                    System.out.println("Error: Ingresa el número del libro que deseas eliminar.");
                } else {
                    break;
                }
            }catch (InputMismatchException e){
                System.out.println("Error: debes ingresar un número válido.");
                sc.nextLine();      // Limpia el bufferdel scanner
            }
        }
        // Eliminar el libro seleccionado
        Libro libroEliminado = libros.remove(i - 1);
        System.out.println("El libro: " + libroEliminado.getTitulo() + ", ha sido eliminado correctamente.");
    }
    
    
    // Método para añadir Libro
    public static Libro agregarLibro(Scanner sc){
        System.out.print("Ingresa el Titulo del libro: ");
        String titulo = sc.nextLine();
                    
        System.out.print("Ingresa el Genero del libro: ");
        String genero = sc.nextLine();
                    
        System.out.print("Ingresa el Autor del libro: ");
        String autor = sc.nextLine();
                    
        System.out.print("Ingresa el ISBN del libro: ");
        String isbn = sc.nextLine();
                    
        LocalDate fechaPublicacion = null;
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    
        while(true){
            try{
                System.out.print("Ingresa la Fecha de Publicacion del libro en formato (dd/MM/yyyy): ");
                String fechaString = sc.nextLine();
                fechaPublicacion =LocalDate.parse(fechaString, formato);
                break; 
            }catch (DateTimeParseException e){
                System.out.println("Error: formato de fecha incorrecto. Usa dd/MM/yyyy (ejemplo: 06/02/2025)");
            }
        }
        return new Libro(titulo, genero, autor, isbn, fechaPublicacion);
    }
}


// Eugen Moga
// PROG09 Ejercicio 1

package prog09_ejer1;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Libro implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    // Atributos del libro
    private String titulo;
    private String genero;
    private String autor;
    private String isbn;
    private LocalDate fechaPublicacion;

    // Constructor
    public Libro(String titulo, String genero, String autor, String isbn, LocalDate fechaPublicacion) {
        this.titulo = titulo;
        this.genero = genero;
        this.autor = autor;
        this.isbn = isbn;
        this.fechaPublicacion = fechaPublicacion;
    }
    
    // Métodos GETTER y SETTER
    public String getTitulo(){
        return titulo;
    }
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    
    public String getGenero(){
        return genero;
    }
    public void setGenero(String genero){
        this.genero = genero;
    }
    
    public String getAutor(){
        return autor;
    }
    public void setAutor(String autor){
        this.autor = autor;
    }
    
    public String getIsbn(){
        return isbn;
    }
    public void setIsbn(String isbn){
        this.isbn = isbn;
    }
    
    public LocalDate getFechaPublicacion(){
        return fechaPublicacion;
    }
    public void setFechaPublicacion(LocalDate fechaPublicacion){
        this.fechaPublicacion = fechaPublicacion;
    }
    
    // Metodo toString
    @Override
    public String toString(){
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "Titulo: " + titulo + ", " +
                "Genero: " + genero + ", " +
                "Autor: " + autor + ", " +
                "ISBN: " + isbn + ", " + 
                "Fecha publicación: " + fechaPublicacion.format(formato);
    }
    
    
}
